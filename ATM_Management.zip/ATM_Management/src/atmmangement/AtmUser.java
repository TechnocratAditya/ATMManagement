package atmmangement;

public class AtmUser {

	private String firstname;
	private String lastname;
	private String pin;
	private String email;
	private float accountBalance;
	
	public AtmUser(String firstname, String lastname, String pin,  String email,float accountBalance) {
		
		this.firstname = firstname;
		this.lastname = lastname;
		this.pin = pin;
		this.email=email;
		this.accountBalance = accountBalance;
		
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public float depositMoney(float amount) {
		this.accountBalance += amount;
		return this.accountBalance;
	}

	public float withdrawMoney(float amount) {
		this.accountBalance -= amount;
		return this.accountBalance;
	}
}


// The addition assignment ( += ) operator adds the value of the right operand to a variable and assigns the result to the variable.
