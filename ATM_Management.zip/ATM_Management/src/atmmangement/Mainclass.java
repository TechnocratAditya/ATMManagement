package atmmangement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Mainclass {

	public static void main(String[] args) throws IOException {
		AtmUser user = null;
		boolean stayINloop = true;
		
		while(stayINloop) {
			
			 if (user == null) {
				 
				 try {
				 user = singInOrCreateNewAccount();
				 }
				 catch (IOException ex){
					 System.out.println("There was an error Creating your account,let's try that again ");
					 continue;
				 }
				 
			 }
			 
			 displayOptions(user);
			 
			 
			 BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
				String response = bufferedReader.readLine();
				
				switch(response) {
				case "1":
					boolean depositSuccssful = false;
					while(!depositSuccssful) {
						System.out.println("how much would you like to deposit ?");
						String amount = bufferedReader.readLine();
						Float convertedAmount = isvalidNumber(amount);
						if(convertedAmount != null) {
						user.depositMoney(convertedAmount);
						displayAccountBalance(user);
						depositSuccssful = true;
					}
						else{
							System.out.println("That's not a valid no !");

						}
				}
				break;
					
				case "2":
					boolean withdrawSuccessful = false;
					while(!withdrawSuccessful) {
						System.out.println("how much do you want to withdraw ?");
						String amount = bufferedReader.readLine();
						Float convertedAmount = isvalidNumber(amount);
						if(convertedAmount != null) {
						user.withdrawMoney(convertedAmount);
						displayAccountBalance(user);
						withdrawSuccessful = true;
					}
						else{
							System.out.println("That's not a valid no !");

						}
				}
					break;
			
				case "3":
					displayAccountBalance(user);
					break;
					
				case "4":
					stayINloop = false;
					System.out.println("Thank you for Visiting.. ");
					break;
					default:
						
				
				}
			 
		}
		

	}
		
	private  static AtmUser singInOrCreateNewAccount() throws IOException{
		System.out.println("Welcome to the bank  EduBrigde");
		System.out.println("Let's get started and create and account or you..");
		System.out.println("What's your first name ?");

		
		BufferedReader  reader = new BufferedReader(new InputStreamReader(System.in));
		String firstname = reader.readLine();
		
		System.out.println("What is your last name?");
		String lastname = reader.readLine();
		
		
		System.out.println("What is your emailid?");
		String email = reader.readLine();
		
		String pin ="";
		boolean isvalidpin = false;
		while(!isvalidpin) {
		System.out.println("What do you want your pin to be ? (need to be a 4 digit no)");
	    pin = reader.readLine();
		
		if (pin.length()== 4) {
			Float integer = isvalidNumber(pin);
			
			if(integer == null) {
			System.out.println("Pin was invalid, need to be all digits");
			}else {
				isvalidpin=true;
			}
		}
		else {
			System.out.println("Pin was Not 4 digit");
		}
		
	}
		
		AtmUser user = new AtmUser(firstname, lastname, pin, email, 0f);
		
		System.out.println("Would you like to make an initial deposit ? Type yes if you want to..");
	    String answer = reader.readLine();
	    
	    if ("yes".equalsIgnoreCase(answer)) {
			System.out.println("Great! How much?");
			String amount = reader.readLine();
			
			Float convertedAmount = isvalidNumber(amount);
			if(convertedAmount != null) {
				user.depositMoney(convertedAmount);
			}
			else {
				System.out.println("That's not a valid no ! ");
			}
			
	    }
	    
	    return user;

	}
	
	private static Float isvalidNumber(String value) {
		
       try {
	   return Float.parseFloat(value);
	
       }
       catch(Exception ex){
    	   return null;

     }
     
}

	 private static void displayOptions(AtmUser user) throws IOException {
			System.out.println("Hello " + user.getFirstname() + " What can the bank of Edubridge do for you \n \n");
			System.out.println("1. Deposit");
			System.out.println("2. Withdraw");
			System.out.println("3. Check Balance");
			System.out.println("4. Exit");
			System.out.println("Enter 1 , 2 , 3 or 4");
			
	 }

	private static void displayAccountBalance(AtmUser user){
		 
		 System.out.println( "Your New balance is $" + user.getAccountBalance());
		 
	 }

}
